import React, {useState, useEffect} from 'react'

function FileList({files}) {
  if (!files || files.length === 0) return <p>No files found in public/assets.</p>
  return (
    <ul>
      {files.map((f, i) => (
        <li key={i}><a href={`/assets/${f}`} target="_blank" rel="noreferrer">{f}</a></li>
      ))}
    </ul>
  )
}

export default function App(){
  const [files, setFiles] = useState([])

  useEffect(() => {
    // fetch a generated JSON list
    fetch('/assets/files.json').then(r => r.json()).then(setFiles).catch(()=>setFiles([]))
  },[])

  return (
    <div className="app">
      <header>
        <h1>MSD Project - Frontend (Converted)</h1>
        <p>Your uploaded files are available in <code>/public/assets</code>. Click to preview.</p>
      </header>
      <main>
        <section className="content">
          <h2>Files extracted from the uploaded ZIP</h2>
          <FileList files={files} />
        </section>
      </main>
      <footer>
        <p>Prepared by ChatGPT - replace this scaffold with your React components.</p>
      </footer>
    </div>
  )
}
